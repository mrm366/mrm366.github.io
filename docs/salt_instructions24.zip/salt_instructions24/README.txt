This archive contains information for authors of papers in the 
proceedings of SALT 24.  Please see salt24-instructions.pdf for full 
author instructions, including a description of the files in this 
archive.

